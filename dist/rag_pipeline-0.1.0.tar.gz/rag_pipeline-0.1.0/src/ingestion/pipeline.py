import uuid
from typing import List, Dict, Any
from pathlib import Path
from qdrant_client.models import Distance, VectorParams, PointStruct
from sqlalchemy.orm import Session

from src.database.connection import get_neo4j_driver
from .parser import DocumentParser
from .chunker import TextChunker
from .embedder import Embedder
from ..agents.extraction import ExtractionAgent
from ..database.models import DocumentMetadata, DocumentChunk

class IngestionPipeline:
    """
    Orchestrates the ingestion of scientific data:
    1. Parse (PDF/CSV -> Text)
    2. Chunk (Text -> Chunks)
    3. Embed (Chunks -> Vectors)
    4. Store (Vectors -> Qdrant, Metadata -> PostgreSQL)
    """
    
    def __init__(self, db_session: Session, qdrant_client, collection_name="scientific_papers"):
        self.db = db_session
        self.qdrant = qdrant_client
        self.neo4j_driver = get_neo4j_driver()
        self.collection_name = collection_name
        
        self.parser = DocumentParser()
        self.chunker = TextChunker()
        self.embedder = Embedder()
        self.extraction_agent = ExtractionAgent()
        
        self._ensure_qdrant_collection()

    def _ensure_qdrant_collection(self):
        """Creates the Qdrant collection if it doesn't exist."""
        collections = self.qdrant.get_collections().collections
        exists = any(c.name == self.collection_name for c in collections)
        
        if not exists:
            self.qdrant.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(
                    size=self.embedder.vector_size,
                    distance=Distance.COSINE
                )
            )

    def process_file(self, file_path: str | Path) -> str:
        """
        Process a single file and store it in both DBs.
        Returns the Document ID.
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        # 1. Parse
        print(f"Parsing {path.name}...")
        parsed_data = self.parser.parse_file(path)
        text = parsed_data["text"]
        metadata = parsed_data["metadata"]
        
        # 2. Chunk
        # For CSVs: parser already returns individual row chunks (pre_chunked)
        # For PDFs: run through the text chunker with overlap
        if "pre_chunked" in parsed_data:
            chunks = parsed_data["pre_chunked"]
            print(f"CSV mode: using {len(chunks)} pre-chunked rows (1 row = 1 vector)...")
        else:
            print("Chunking text...")
            chunks = self.chunker.split_text(text)
        
        if not chunks:
            print("No text extracted to chunk.")
            return None

        # 3. Embed
        print(f"Embedding {len(chunks)} chunks...")
        embeddings = self.embedder.embed_texts(chunks)

        # 4. Store
        print("Storing in PostgreSQL and Qdrant...")
        doc_id = str(uuid.uuid4())
        
        # Write to PostgreSQL (Lineage/Metadata)
        db_doc = DocumentMetadata(
            id=doc_id,
            title=metadata["title"],
            source_type=metadata["source_type"],
            file_path=str(path),
            num_chunks=len(chunks)
        )
        self.db.add(db_doc)
        
        # Write to Qdrant & link chunks in PostgreSQL
        qdrant_points = []
        for i, (chunk_text, embedding) in enumerate(zip(chunks, embeddings)):
            chunk_id = str(uuid.uuid4())
            
            # DB Lineage
            db_chunk = DocumentChunk(
                id=chunk_id,
                document_id=doc_id,
                chunk_index=i,
                qdrant_point_id=chunk_id
            )
            self.db.add(db_chunk)
            
            # Qdrant Vector
            qdrant_points.append(
                PointStruct(
                    id=chunk_id,
                    vector=embedding,
                    payload={
                        "document_id": doc_id,
                        "chunk_index": i,
                        "text": chunk_text,
                        "title": metadata["title"]
                    }
                )
            )
            
        # Commit to Postgres
        self.db.commit()
        
        # Upload to Qdrant
        self.qdrant.upsert(
            collection_name=self.collection_name,
            points=qdrant_points
        )
        
        # 5. Extract and Store Graph (Level 2)
        print("Extracting Graph Relationships to Neo4j...")
        self._extract_and_store_graph(doc_id, metadata, text)
        
        print(f"Successfully ingested {path.name}. Document ID: {doc_id}")
        return doc_id

    def _extract_and_store_graph(self, doc_id: str, metadata: dict, full_text: str):
        """
        Creates Graph nodes and relationships in Neo4j using the ExtractionAgent.
        (Author) -[WROTE]-> (Paper)
        """
        if metadata.get("source_type") == "pdf":
            # Use the LLM / Extraction Agent to get perfect authors and titles
            extracted = self.extraction_agent.extract_metadata(full_text[:3000])
            title = extracted.get("title", metadata.get("title", "Unknown Paper"))
            authors = extracted.get("authors", ["Unknown Author"])
        else:
            title = metadata.get("title", "Unknown Dataset")
            authors = ["Dataset Author"]
        
        query = """
        MERGE (p:Paper {id: $doc_id})
        SET p.title = $title
        WITH p
        UNWIND $authors AS author_name
        MERGE (a:Author {name: author_name})
        MERGE (a)-[:WROTE]->(p)
        """
        
        try:
            with self.neo4j_driver.session() as session:
                session.run(query, authors=authors, doc_id=doc_id, title=title)
        except Exception as e:
            print(f"Failed to write to Neo4j: {e}")
